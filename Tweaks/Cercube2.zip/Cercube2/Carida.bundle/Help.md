##### Slow Downloads

When saving videos via Cercube, the download engine always fetches the videos from their original source. YouTube started throttling speeds in 2018 for specific formats. 

If you find out that a video is taking too long to download, please try a different quality or format.



##### Support

You can always send an email to [support@cercube.com](mailto:support@cercube.com) in case you have further questions.

